# Technical Analysis

## Architecture Decision

Partition:
...

Consumer Group:
...

Consumer:
...

Event Key / Ordering:
...

Offset / Commit:
...

Delivery Semantics:
...

Alasan:
...

## Failure Analysis

Action:
...

Observation:
...

Diagnosis:
...

Fix:
...

Verification:
...
